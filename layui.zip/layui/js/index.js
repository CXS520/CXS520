var items = new Array();
items[0]=undefined;
var index = 1;
layui.use('element', function() {
	var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块

	//监听导航点击
	/*element.on('nav(demo)', function(elem){
	  aa();
	  
	});*/

	element.on("nav(menu)", function(elem) {
		//console.log(elem.attr("name")); //得到当前点击的DOM对象
		//alert("aa");
		var name = elem.attr("name");
		var id = name;

		
		var href = elem.attr("_href");
		var text = elem.text();
		console.log(items);
		
		if(items.indexOf(id) == -1) {
			items[index] = id;
			index++;
			element.tabAdd("main_content", {
				title: text,
				id: id,
				content: '<span id="' + name + '_container"></span><script>loadTab("#' + name + '_container", "' + href + '");</script>' //支持传入html
			});

			element.tabChange("main_content", id);
		}else{
			element.tabChange("main_content", id);
		}

	});
	
	
	/*element.on('tab(main_content)', function(data){
	  console.log(this); //当前Tab标题所在的原始DOM元素
	  console.log(data.index); //得到当前Tab的所在下标
	  console.log(data.elem); //得到当前的Tab大容器
	});*/
	
   	element.on('tabDelete(main_content)', function(data){
   		
//	  console.log(this); //当前Tab标题所在的原始DOM元素
	  console.log(data.index); //得到当前Tab的所在下标
	  var ind = data.index;
	  var newArray = new Array();
	  for(var i = 0;i<items.length;i++){
	  	if(i<ind){
	  		newArray[i] = items[i];
	  	}else if(i>ind){
	  		newArray[i-1]=items[i];
	  	}
	  }
//	  delete items[ind];
//	 console.log(items);
	items = newArray;
	 index--;
	  
//	  console.log(data.elem); //得到当前的Tab大容器
	});
  
  
	window.loadTab = function(selector, url) {
		console.log("url: " + url);
		$(selector).load(url);
	}

});

/*

layui.use('element', function() {
	var $ = layui.jquery,
		element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块

	//触发事件
	var active = {
		tabAdd: function() {
			//新增一个Tab项
			element.tabAdd('demo', {
				title: '新选项' + (Math.random() * 1000 | 0) //用于演示
					,
				content: '内容' + (Math.random() * 1000 | 0),
				id: new Date().getTime() //实际使用一般是规定好的id，这里以时间戳模拟下
			})
		},
		tabDelete: function(othis) {
			//删除指定Tab项
			element.tabDelete('demo', '44'); //删除：“商品管理”

			othis.addClass('layui-btn-disabled');
		},
		tabChange: function() {
			//切换到指定Tab项
			element.tabChange('demo', '22'); //切换到：用户管理
		}
	};

	$('.site-demo-active').on('click', function() {
		var othis = $(this),
			type = othis.data('type');
		active[type] ? active[type].call(this, othis) : '';
	});

	//Hash地址的定位
	var layid = location.hash.replace(/^#test=/, '');
	element.tabChange('test', layid);

	element.on('tab(test)', function(elem) {
		location.hash = 'test=' + $(this).attr('lay-id');
	});
	
	
	

});*/